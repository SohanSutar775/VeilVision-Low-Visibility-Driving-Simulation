"""
Low Visibility Vehicle Guidance System - Python simulation (Option B)
Thermal 3-tier Edge AI + Dynamic Sensor Fusion

Tier 1 (STM32)  : environment sensing -> Visibility Index (0-100)
Tier 2 (Pi 5)   : LWIR thermal frame + LiDAR occupancy grid -> 2-channel tensor -> classifier
Tier 3 (alerts) : detection confidence compared with a threshold that adapts to the Visibility Index

IMPORTANT: sensor physics here are simple ILLUSTRATIVE approximations, not measured data.
Accuracy numbers are on synthetic data. Replace the constants (marked CONFIG) with your own
test results when you have them.

Run:  python low_visibility_sim.py
Needs: numpy, matplotlib, scikit-learn   (optional: tensorflow for the Keras CNN)
Output: printed tables + PNG figures saved next to this script.
"""
import warnings
warnings.filterwarnings("ignore")
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPClassifier

rng = np.random.default_rng(7)
N = 32                                   # frame size (N x N)
CLASSES = ["none", "person", "animal", "vehicle"]
TEMP = {1: 1.0, 2: 0.9, 3: 0.7}          # CONFIG: relative thermal signature per class
SPEED_KMH = 60                           # CONFIG: vehicle speed
PRESETS = {"Clear sky": 90, "Light fog": 60, "Heavy smog": 35, "Dense valley mist": 15}

# ---------------------------------------------------------------- Tier 1: environment
def visibility_m(V):            # meteorological visibility in metres
    return 20 + 3.0 * V

def stopping_distance(speed_kmh):
    v = speed_kmh / 3.6          # 1 s reaction + 6 m/s^2 braking
    return v * 1.0 + v * v / 12

def alert_threshold(V):         # adaptive: lower threshold in fog -> earlier, more cautious warnings
    return 0.50 + 0.35 * V / 100

# ---------------------------------------------------------------- Tier 2: sensor models
def blob(shape_id, scale):
    """Silhouette mask (N x N) for each obstacle class, scaled by apparent size."""
    m = np.zeros((N, N))
    cx, base = N // 2, int(N * 0.8)
    s = max(1.0, scale)
    if shape_id == 1:            # person: tall and narrow
        w, h = max(1, int(.25 * s)), max(2, int(1.0 * s))
    elif shape_id == 2:          # animal: low and wide
        w, h = max(2, int(.9 * s)), max(1, int(.45 * s))
    else:                        # vehicle: wide and boxy
        w, h = max(2, int(1.3 * s)), max(2, int(.7 * s))
    m[max(0, base - h):base, max(0, cx - w // 2):min(N, cx + w // 2 + 1)] = 1
    return m

def thermal_frame(cls, d, V):
    k = 0.004 + 0.02 * (1 - V / 100)             # CONFIG: thermal attenuation grows with fog
    img = rng.normal(0.15, 0.09, (N, N))         # cold background + sensor noise
    if rng.random() < 0.6:                       # warm clutter (hot asphalt, exhaust) - not an obstacle
        cy, cx = rng.integers(8, N - 4), rng.integers(4, N - 4)
        img[cy:cy + 3, cx:cx + 3] += rng.uniform(0.2, 0.6)
    if cls:
        img += blob(cls, 26 * 8 / (d + 8)) * TEMP[cls] * np.exp(-k * d)
    return np.clip(img, 0, 1.2)

def rgb_frame(cls, d, V):
    T = np.exp(-3.912 * d / visibility_m(V))     # Koschmieder contrast falloff
    fog = 0.35 + 0.5 * (1 - V / 100)
    img = rng.normal(fog, 0.05, (N, N))
    if cls:
        img -= blob(cls, 26 * 8 / (d + 8)) * 0.4 * T
    return np.clip(img, 0, 1.2)

def lidar_grid(cls, d, V):
    R = 40 + 0.8 * V                             # CONFIG: effective LiDAR range (m)
    p_hit = np.exp(-(d / R) ** 2) if cls else 0.0
    grid = (rng.random((N, N)) < (0.005 + 0.03 * (1 - V / 100))).astype(float)  # fog backscatter clutter
    if cls:
        foot = {1: (1, 1), 2: (2, 1), 3: (3, 2)}[cls]
        row = int(np.clip(N - 1 - d / 80 * (N - 2), 0, N - 2))
        for dr in range(foot[1]):
            for dc in range(foot[0]):
                if rng.random() < p_hit:
                    grid[row - dr, N // 2 - foot[0] // 2 + dc] = 1
    return grid

def make_input(cls, d, V, mode):
    t, l, r = thermal_frame(cls, d, V), lidar_grid(cls, d, V), rgb_frame(cls, d, V)
    if mode == "fused":   return np.stack([t, l])         # 2-channel tensor (thermal + LiDAR)
    if mode == "thermal": return t[None]
    return r[None]                                        # camera-only baseline

# ---------------------------------------------------------------- dataset + models
def dataset(n, mode):
    X, y, Vs = [], [], []
    for _ in range(n):
        cls = int(rng.integers(0, 4))
        V, d = rng.uniform(5, 100), rng.uniform(5, 80)
        X.append(make_input(cls, d, V, mode).ravel()); y.append(cls); Vs.append(V)
    return np.array(X), np.array(y), np.array(Vs)

def train(mode, n=7000):
    X, y, _ = dataset(n, mode)
    clf = MLPClassifier(hidden_layer_sizes=(96, 32), max_iter=80, random_state=0)
    clf.fit(X, y)
    return clf

def keras_cnn():
    """Optional: the real edge model. Same 2x32x32 input; convert to TensorFlow Lite for the Pi 5.
    Not used by default (and not run in this script's test) - shown so you can swap it in."""
    import tensorflow as tf
    return tf.keras.Sequential([
        tf.keras.layers.Input((N, N, 2)),
        tf.keras.layers.Conv2D(8, 3, activation="relu"), tf.keras.layers.MaxPool2D(),
        tf.keras.layers.Conv2D(16, 3, activation="relu"), tf.keras.layers.MaxPool2D(),
        tf.keras.layers.Flatten(), tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.Dense(4, activation="softmax")])

# ---------------------------------------------------------------- Tier 3: approach simulation
FIXED_THR = 0.70                          # conventional ADAS: one fixed threshold

def detection_distance(model, mode, V, cls=1, trials=8):
    """Drive toward an obstacle from 80 m; return mean distance of first CORRECT alert
    (probability of the true class >= threshold on 2 frames in a row). 0 = never detected.
    Only the fused system uses the adaptive threshold; the baselines use a fixed one."""
    thr = alert_threshold(V) if mode == "fused" else FIXED_THR
    out = []
    for _ in range(trials):
        hits, found = 0, 0.0
        for d in np.arange(80, 4, -2.0):
            p_obj = model.predict_proba(make_input(cls, d, V, mode).reshape(1, -1))[0][cls]
            hits = hits + 1 if p_obj >= thr else 0
            if hits >= 2:
                found = d; break
        out.append(found)
    return float(np.mean(out))

if __name__ == "__main__":
    print("Training classifiers on synthetic frames (about a minute)...")
    models = {m: train(m) for m in ["fused", "thermal", "rgb"]}

    # 1) accuracy by visibility
    print("\nClassification accuracy by visibility band (synthetic test set)")
    print(f"{'Visibility':<14}{'RGB only':>10}{'Thermal':>10}{'Thermal+LiDAR':>16}")
    bands = [(0, 25), (25, 50), (50, 75), (75, 100)]
    for lo, hi in bands:
        row = []
        for m in ["rgb", "thermal", "fused"]:
            X, y, V = dataset(1500, m)
            mask = (V >= lo) & (V < hi)
            row.append(models[m].score(X[mask], y[mask]) * 100)
        print(f"{lo:>3}-{hi:<9}{row[0]:>9.0f}%{row[1]:>9.0f}%{row[2]:>15.0f}%")

    # 2) detection distance vs stopping distance
    stop = stopping_distance(SPEED_KMH)
    print(f"\nFirst-alert distance for a pedestrian at {SPEED_KMH} km/h (stopping distance {stop:.0f} m)")
    print("(0 m = never detected before 5 m)")
    print(f"{'Condition':<20}{'Index':>6}{'RGB':>8}{'Thermal':>9}{'Fused+adaptive':>16}  Verdict")
    sweep = np.arange(10, 100, 10)
    curves = {"rgb": [], "thermal": [], "fused": []}
    for V in sweep:
        for m in curves:
            curves[m].append(detection_distance(models[m], m, V))
    for name, V in PRESETS.items():
        r = {m: detection_distance(models[m], m, V) for m in curves}
        ok = "system OK" if r["fused"] > stop * 1.1 else "too late"
        ok2 = "camera OK" if r["rgb"] > stop * 1.1 else "camera too late"
        print(f"{name:<20}{V:>6}{r['rgb']:>7.0f}m{r['thermal']:>8.0f}m{r['fused']:>15.0f}m  {ok}; {ok2}")

    # 3) figures
    fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.plot(sweep, curves["rgb"], "o-", label="Camera only (RGB)")
    ax.plot(sweep, curves["thermal"], "s-", label="Thermal only")
    ax.plot(sweep, curves["fused"], "^-", label="Thermal + LiDAR, adaptive threshold")
    ax.axhline(stop, color="red", ls="--", label=f"Stopping distance at {SPEED_KMH} km/h")
    ax.set_xlabel("Visibility Index"); ax.set_ylabel("First-alert distance (m)")
    ax.set_title("Detection distance vs visibility (synthetic model)"); ax.legend(); ax.grid(alpha=.3)
    fig.tight_layout(); fig.savefig("detection_distance.png", dpi=150)

    fig, axes = plt.subplots(3, 4, figsize=(11, 7))
    for j, (name, V) in enumerate(PRESETS.items()):
        d = 35
        axes[0, j].imshow(rgb_frame(1, d, V), cmap="gray", vmin=0, vmax=1)
        axes[1, j].imshow(thermal_frame(1, d, V), cmap="inferno", vmin=0, vmax=1)
        axes[2, j].imshow(lidar_grid(1, d, V), cmap="Greens", vmin=0, vmax=1)
        axes[0, j].set_title(f"{name} ({V})")
    for i, lab in enumerate(["RGB camera", "LWIR thermal", "LiDAR grid"]):
        axes[i, 0].set_ylabel(lab)
    for a in axes.ravel(): a.set_xticks([]); a.set_yticks([])
    fig.suptitle("Pedestrian at 35 m under each condition (synthetic frames)")
    fig.tight_layout(); fig.savefig("sensor_frames.png", dpi=150)
    print("\nSaved: detection_distance.png, sensor_frames.png")
